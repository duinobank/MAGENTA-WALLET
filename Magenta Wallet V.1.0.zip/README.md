Magenta Wallet V.1.0 ♦
NOTE: This is not a legitamate crypto wallet. You can not send funds or change private keys. This wallet is for experementation perposes only, It is a 
handy and quick way of checking your Ethereum wallet balance. To start simply run MAGENTA Wallet v.1.0.py and enter your public ethereum adress. Your Ethereum 
balance, account and last transaction will pe desplayed. You also have a Network tick suggesting your internet speed. 
NOTE: I am not responsible for any cryptocurrency lost, This is because you are only entering your public adress that is accesible to anyone. With the public 
adress the only ability you have is to send crypto.
